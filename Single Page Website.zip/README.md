
  # Single Page Website

  This is a code bundle for Single Page Website. The original project is available at https://www.figma.com/design/TyzXMEze9vkcvVREY9uB6c/Single-Page-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  